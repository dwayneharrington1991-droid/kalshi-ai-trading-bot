"""
Trade Execution Job

This job takes a position and executes it as a trade.
"""
import asyncio
import uuid
from datetime import datetime
from typing import Optional, Dict

from src.utils.database import DatabaseManager, Position
from src.config.settings import settings
from src.utils.logging_setup import get_trading_logger
from src.clients.kalshi_client import KalshiClient, KalshiAPIError
from src.utils.market_prices import get_market_prices, is_tradeable_market

async def execute_position(
    position: Position, 
    live_mode: bool, 
    db_manager: DatabaseManager, 
    kalshi_client: KalshiClient
) -> bool:
    """
    Executes a single trade position.
    
    Args:
        position: The position to execute.
        live_mode: Whether to execute a live or simulated trade.
        db_manager: The database manager instance.
        kalshi_client: The Kalshi client instance.
        
    Returns:
        True if execution was successful, False otherwise.
    """
    logger = get_trading_logger("trade_execution")
    logger.info(f"🎯 Executing position for market: {position.market_id}")
    logger.info(f"🎛️ Live mode: {live_mode}")
    
    if live_mode:
        logger.warning(f"💰 PLACING LIVE ORDER - Real money will be used for {position.market_id}")
        try:
            # Get current market prices to determine the appropriate price field
            market_data = await kalshi_client.get_market(position.market_id)
            market = market_data.get('market', {})
            
            # For market orders, use the ask price based on which side we're buying
            side_lower = position.side.lower()
            client_order_id = str(uuid.uuid4())
            
            # Prepare order parameters
            order_params = {
                "ticker": position.market_id,
                "client_order_id": client_order_id,
                "side": side_lower,
                "action": "buy",
                "count": position.quantity,
                "type_": "market"
            }
            
            # Add the appropriate price field based on side
            # For market orders, we use the ask price (what we're willing to pay)
            # get_market_prices normalizes both API v2 (dollar floats) and legacy (cent ints)
            # to dollar values (0.0–1.0). place_order expects cents (int), so multiply by 100.
            _yes_bid, yes_ask_dollars, _no_bid, no_ask_dollars = get_market_prices(market)

            # --- Price sanity checks (issue #42) ---
            # Guard 1: Collection/aggregate tickers return $1.00/$1.00 and are not
            # directly tradeable.  Placing an order against them yields HTTP 400
            # invalid_price.  Reject early if both asks are at or above $0.99.
            if not is_tradeable_market(market):
                logger.warning(
                    f"⚠️  Skipping {position.market_id}: collection/aggregate ticker "
                    f"(yes_ask={yes_ask_dollars:.4f}, no_ask={no_ask_dollars:.4f}). "
                    "Both asks >= $0.99 — market is not directly tradeable (issue #42)."
                )
                return False

            # Guard 2: Reject any price that would convert to 0¢ or >= 100¢ — these
            # are outside the valid Kalshi order range and will be rejected by the API.
            ask_dollars = yes_ask_dollars if side_lower == "yes" else no_ask_dollars
            ask_cents = int(round(ask_dollars * 100))
            if ask_cents <= 0 or ask_cents >= 100:
                logger.warning(
                    f"⚠️  Skipping {position.market_id}: {side_lower} ask price "
                    f"{ask_dollars:.4f} converts to {ask_cents}¢ which is outside the "
                    "valid Kalshi range (1–99¢). Cannot place order (issue #42)."
                )
                return False
            # --- End price sanity checks ---

            if side_lower == "yes":
                yes_ask_cents = int(round(yes_ask_dollars * 100))
                if not (1 <= yes_ask_cents <= 99):
                    logger.warning(
                        f"Price sanity check failed for {position.market_id}: "
                        f"yes_ask_cents={yes_ask_cents} is outside valid range 1–99 "
                        f"(raw yes_ask_dollars={yes_ask_dollars:.4f}). Skipping order."
                    )
                    return False
                order_params["yes_price"] = yes_ask_cents
            else:  # side_lower == "no"
                no_ask_cents = int(round(no_ask_dollars * 100))
                if not (1 <= no_ask_cents <= 99):
                    logger.warning(
                        f"Price sanity check failed for {position.market_id}: "
                        f"no_ask_cents={no_ask_cents} is outside valid range 1–99 "
                        f"(raw no_ask_dollars={no_ask_dollars:.4f}). Skipping order."
                    )
                    return False
                order_params["no_price"] = no_ask_cents

            # --- Balance guard: never place an order we cannot afford ---
            # Fail closed: if the balance check itself errors, skip the order
            # rather than risk placing it against a stale bankroll figure.
            order_cost_cents = ask_cents * position.quantity
            try:
                balance_response = await kalshi_client.get_balance()
                available_cents = int(balance_response.get("balance", 0) or 0)
            except Exception as e:
                logger.error(
                    f"❌ Could not verify balance before order for {position.market_id} "
                    f"({e}); skipping order (fail-closed)."
                )
                return False
            if order_cost_cents > available_cents:
                logger.warning(
                    f"⚠️  Insufficient balance for {position.market_id}: order needs "
                    f"~{order_cost_cents}¢ ({position.quantity} @ {ask_cents}¢) but only "
                    f"{available_cents}¢ available. Skipping order."
                )
                return False
            # --- End balance guard ---

            logger.info(f"Placing order with params: {order_params}")
            order_response = await kalshi_client.place_order(**order_params)
            
            # For a market order, the fill price is not guaranteed.
            # A more robust implementation would query the /fills endpoint
            # to confirm the execution price after the fact.
            # For now, we will optimistically assume it fills at the entry price.
            fill_price = position.entry_price

            await db_manager.update_position_to_live(position.id, fill_price)
            logger.info(f"✅ LIVE ORDER PLACED for {position.market_id}. Order ID: {order_response.get('order', {}).get('order_id')}")
            logger.info(f"💰 Real money used: ${position.quantity * fill_price:.2f}")
            return True

        except KalshiAPIError as e:
            logger.error(f"❌ FAILED to place LIVE order for {position.market_id}: {e}")
            return False
    else:
        # Simulate the trade
        await db_manager.update_position_to_live(position.id, position.entry_price)
        logger.info(f"📝 PAPER TRADE SIMULATED for {position.market_id} - No real money used")
        logger.info(f"📊 Would have used: ${position.quantity * position.entry_price:.2f}")
        return True


async def place_sell_limit_order(
    position: Position,
    limit_price: float,
    db_manager: DatabaseManager,
    kalshi_client: KalshiClient
) -> bool:
    """
    Place a sell limit order to close an existing position.
    
    Args:
        position: The position to close
        limit_price: The limit price for the sell order (in dollars)
        db_manager: Database manager
        kalshi_client: Kalshi API client
    
    Returns:
        True if order placed successfully, False otherwise
    """
    logger = get_trading_logger("sell_limit_order")
    
    try:
        import uuid
        client_order_id = str(uuid.uuid4())
        
        # Convert price to cents for Kalshi API
        limit_price_cents = int(limit_price * 100)
        
        # For sell orders, we need to use the opposite side logic:
        # - If we have YES position, we sell YES shares (action="sell", side="yes")
        # - If we have NO position, we sell NO shares (action="sell", side="no")
        side = position.side.lower()  # "YES" -> "yes", "NO" -> "no"
        
        order_params = {
            "ticker": position.market_id,
            "client_order_id": client_order_id,
            "side": side,
            "action": "sell",  # We're selling our existing position
            "count": position.quantity,
            "type_": "limit"
        }
        
        # Add the appropriate price parameter based on what we're selling
        if side == "yes":
            order_params["yes_price"] = limit_price_cents
        else:
            order_params["no_price"] = limit_price_cents
        
        logger.info(f"🎯 Placing SELL LIMIT order: {position.quantity} {side.upper()} at {limit_price_cents}¢ for {position.market_id}")
        
        # Place the sell limit order
        response = await kalshi_client.place_order(**order_params)
        
        if response and 'order' in response:
            order_id = response['order'].get('order_id', client_order_id)
            
            # Record the sell order in the database (we could add a sell_orders table if needed)
            logger.info(f"✅ SELL LIMIT ORDER placed successfully! Order ID: {order_id}")
            logger.info(f"   Market: {position.market_id}")
            logger.info(f"   Side: {side.upper()} (selling {position.quantity} shares)")
            logger.info(f"   Limit Price: {limit_price_cents}¢")
            logger.info(f"   Expected Proceeds: ${limit_price * position.quantity:.2f}")
            
            return True
        else:
            logger.error(f"❌ Failed to place sell limit order: {response}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Error placing sell limit order for {position.market_id}: {e}")
        return False


async def place_profit_taking_orders(
    db_manager: DatabaseManager,
    kalshi_client: KalshiClient,
    profit_threshold: float = 0.25  # 25% profit target
) -> Dict[str, int]:
    """
    Place sell limit orders for positions that have reached profit targets.
    
    Args:
        db_manager: Database manager
        kalshi_client: Kalshi API client
        profit_threshold: Minimum profit percentage to trigger sell order
    
    Returns:
        Dictionary with results: {'orders_placed': int, 'positions_processed': int}
    """
    logger = get_trading_logger("profit_taking")
    
    results = {'orders_placed': 0, 'positions_processed': 0}
    
    try:
        # Get all open live positions
        positions = await db_manager.get_open_live_positions()
        
        if not positions:
            logger.info("No open positions to process for profit taking")
            return results
        
        logger.info(f"📊 Checking {len(positions)} positions for profit-taking opportunities")
        
        for position in positions:
            try:
                results['positions_processed'] += 1
                
                # Get current market data
                market_response = await kalshi_client.get_market(position.market_id)
                market_data = market_response.get('market', {})
                
                if not market_data:
                    logger.warning(f"Could not get market data for {position.market_id}")
                    continue
                
                # Get current price based on position side
                if position.side == "YES":
                    current_price = market_data.get('yes_price', 0) / 100  # Convert cents to dollars
                else:
                    current_price = market_data.get('no_price', 0) / 100
                
                # Calculate current profit
                if current_price > 0:
                    profit_pct = (current_price - position.entry_price) / position.entry_price
                    unrealized_pnl = (current_price - position.entry_price) * position.quantity
                    
                    logger.debug(f"Position {position.market_id}: Entry=${position.entry_price:.3f}, Current=${current_price:.3f}, Profit={profit_pct:.1%}, PnL=${unrealized_pnl:.2f}")
                    
                    # Check if we should place a profit-taking sell order
                    if profit_pct >= profit_threshold:
                        # Calculate sell limit price (slightly below current to ensure execution)
                        sell_price = current_price * 0.98  # 2% below current price for quick execution
                        
                        logger.info(f"💰 PROFIT TARGET HIT: {position.market_id} - {profit_pct:.1%} profit (${unrealized_pnl:.2f})")
                        
                        # Place sell limit order
                        success = await place_sell_limit_order(
                            position=position,
                            limit_price=sell_price,
                            db_manager=db_manager,
                            kalshi_client=kalshi_client
                        )
                        
                        if success:
                            results['orders_placed'] += 1
                            logger.info(f"✅ Profit-taking order placed for {position.market_id}")
                        else:
                            logger.error(f"❌ Failed to place profit-taking order for {position.market_id}")
                
            except Exception as e:
                logger.error(f"Error processing position {position.market_id} for profit taking: {e}")
                continue
        
        logger.info(f"🎯 Profit-taking summary: {results['orders_placed']} orders placed from {results['positions_processed']} positions")
        return results
        
    except Exception as e:
        logger.error(f"Error in profit-taking order placement: {e}")
        return results


async def place_stop_loss_orders(
    db_manager: DatabaseManager,
    kalshi_client: KalshiClient,
    stop_loss_threshold: float = -0.10  # 10% stop loss
) -> Dict[str, int]:
    """
    Place sell limit orders for positions that need stop-loss protection.
    
    Args:
        db_manager: Database manager
        kalshi_client: Kalshi API client
        stop_loss_threshold: Maximum loss percentage before triggering stop loss
    
    Returns:
        Dictionary with results: {'orders_placed': int, 'positions_processed': int}
    """
    logger = get_trading_logger("stop_loss_orders")
    
    results = {'orders_placed': 0, 'positions_processed': 0}
    
    try:
        # Get all open live positions
        positions = await db_manager.get_open_live_positions()
        
        if not positions:
            logger.info("No open positions to process for stop-loss orders")
            return results
        
        logger.info(f"🛡️ Checking {len(positions)} positions for stop-loss protection")
        
        for position in positions:
            try:
                results['positions_processed'] += 1
                
                # Get current market data
                market_response = await kalshi_client.get_market(position.market_id)
                market_data = market_response.get('market', {})
                
                if not market_data:
                    logger.warning(f"Could not get market data for {position.market_id}")
                    continue
                
                # Get current price based on position side
                if position.side == "YES":
                    current_price = market_data.get('yes_price', 0) / 100
                else:
                    current_price = market_data.get('no_price', 0) / 100
                
                # Calculate current loss
                if current_price > 0:
                    loss_pct = (current_price - position.entry_price) / position.entry_price
                    unrealized_pnl = (current_price - position.entry_price) * position.quantity
                    
                    # Check if we need stop-loss protection
                    if loss_pct <= stop_loss_threshold:  # Negative loss percentage
                        # Calculate stop-loss sell price
                        stop_price = position.entry_price * (1 + stop_loss_threshold * 1.1)  # Slightly more aggressive
                        stop_price = max(0.01, stop_price)  # Ensure price is at least 1¢
                        
                        logger.info(f"🛡️ STOP LOSS TRIGGERED: {position.market_id} - {loss_pct:.1%} loss (${unrealized_pnl:.2f})")
                        
                        # Place stop-loss sell order
                        success = await place_sell_limit_order(
                            position=position,
                            limit_price=stop_price,
                            db_manager=db_manager,
                            kalshi_client=kalshi_client
                        )
                        
                        if success:
                            results['orders_placed'] += 1
                            logger.info(f"✅ Stop-loss order placed for {position.market_id}")
                        else:
                            logger.error(f"❌ Failed to place stop-loss order for {position.market_id}")
                
            except Exception as e:
                logger.error(f"Error processing position {position.market_id} for stop loss: {e}")
                continue
        
        logger.info(f"🛡️ Stop-loss summary: {results['orders_placed']} orders placed from {results['positions_processed']} positions")
        return results
        
    except Exception as e:
        logger.error(f"Error in stop-loss order placement: {e}")
        return results
